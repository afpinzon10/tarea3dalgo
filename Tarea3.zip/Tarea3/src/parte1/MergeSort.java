package parte1;

public class MergeSort implements NumbersArraySorter{

	
	public void merge(int first, int mid, int last, double[] numbers){
		
	}
	public void mergeSort(int first, int last, double[] numbers){
		int mid = (first+last)/2;
		if(mid != 0){
			mergeSort(first, mid, numbers);
			mergeSort(mid+1, last, numbers);
		}
		
	}
	
	@Override
	public void sort(double[] numbers) {
		mergeSort(0, numbers.length-1, numbers);		
	}

}
