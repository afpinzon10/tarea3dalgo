package parte1;

public interface NumbersArraySorter {

	public void sort(double[] numbers);

}
